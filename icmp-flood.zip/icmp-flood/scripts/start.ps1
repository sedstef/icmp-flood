
docker-compose up -d
Start-Sleep -Seconds 10
docker exec attacker apt update
docker exec attacker apt install -y ansible sshpass
docker cp ../ansible attacker:/ansible
docker exec attacker ansible-playbook -i /ansible/inventory.ini /ansible/playbook.yml

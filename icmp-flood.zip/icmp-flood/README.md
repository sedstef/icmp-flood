
```powershell
podman run --rm -it -v ansible:/srv/ansible -v "$env:USERPROFILE/.ssh:/root/.ssh" ansible ansible-playbook -vv setup_virtualbox_icmp_lab.yml
```
